package com.gu.example.axel.baldr;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
//import android.app.Fragment;
import android.support.v4.app.Fragment;
import com.rarepebble.colorpicker.*;

/**
 * Created by Phoenix on 10-Nov-16.
 */

public class EditLight extends Fragment {
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.color_picker, container, false);

        final ColorPickerView picker = new ColorPickerView(getContext());
        picker.setColor(0xff12345);
        final int color = picker.getColor();
        return view;
    }

}
