package com.gu.example.axel.baldr;

import static org.junit.Assert.*;

/**
 * Created by liwei on 12/12/16.
 */
public class EditLightTest {

}