package com.gu.example.axel.baldr;

import android.content.Context;
import android.os.AsyncTask;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;

/**
 * Created by Axel on 04-Nov-16.
 * Made by Aras and Axel
 */

public class MqttConnection extends MainActivity implements MqttCallback, Runnable {

    MqttAndroidClient client;
    Context c;
    JSONObject json;
     int counter = 0;
    CustomListener cl;

    String clientId; //identifer for each mqtt client connecting to broker
    String homeID;

 //   ListView mainList; // declare a listView
  //  private ProgressDialog mProgressDialog;

   private  LightObject[] lightArray = new LightObject[0];   //declare lightarray
   private  LightObject[] roomArray = new LightObject[0];    // declare roomarray

    // // constructor to initialize the field of object
    public MqttConnection(Context context, CustomListener cl) {
        //Parameterized constructor is used to provide different values to the distinct objects
        c = context;
        this.cl = cl;
        MainActivity ma = (MainActivity) context;
        homeID = ma.homeID;
    }

    //  MqttConnectOptions options = new MqttConnectOptions();
    //options.setUserName("USERNAME");
    // options.setPassword("PASSWORD".toCharArray());

    private void initiateConnection() {
        clientId = MqttClient.generateClientId(); // random generate Cilent id
       // client = new MqttAndroidClient(c, "tcp://localhost:1883", clientId);
      //  client = new MqttAndroidClient(c, "tcp://192.168.0.1:1883", clientId);
      //  client = new MqttAndroidClient(c, "tcp://192.168.0.107:1883", clientId);
        client = new MqttAndroidClient(c, "tcp://prata.technocreatives.com:1883", clientId);
        // second line : to create an instance of mqttclient.
    }   // "c" is context, " server URL",  clientID. the last two part addition to form a unique key.

    public void connect() {
        initiateConnection();
        try {
            IMqttToken token = client.connect(); //declare a token variable  and make connection to broker
            // imqttToken tracking completion of asynchronous tasks
            token.setActionCallback(new IMqttActionListener() {

                // the method will return a token  to tracing state of operation
                // whenever the action is performed, the listenner will listen
                // to it and revert back connection state change to token.
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    // We are connected
                    System.out.println("Connected");
                    long unixTimestamp = (System.currentTimeMillis() / 1000L);
                    JSONObject jsonPresence = new JSONObject(); // declare Json object
                    // instantiate the json object
                    try { // initialise the Json object
                        jsonPresence.put("version", 1); // add value into json object
                        jsonPresence.put("groupName", "Baldr");
                        jsonPresence.put("groupNumber", "7");
                        jsonPresence.put("connectedAt", unixTimestamp);
                        jsonPresence.put("rfcs", "[RFC 1, RFC 17, RFC 18]");
                        jsonPresence.put("clientVersion", "1.0");
                        jsonPresence.put("clientSoftware", "Baldr Android Client");
                        publishJSON("presence/" + clientId, jsonPresence);
                    }catch (JSONException e){
                        e.printStackTrace();
                    } // printstacktrace to print the throwable and its backtrace to standard output error stream.
                    subscribe();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    // Something went wrong e.g. connection timeout or firewall problems
                    System.out.print("Failed to connect");
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //Subcribe to broker
    public void subscribe() {

        try {
            client.setCallback(this); // " this " refer to the topic
            // Sets the callback method to use for tracing events that happen asynchronously.
            client.subscribe("lightcontrol/home/"+ homeID +"/light/+/info", 0);
            System.out.println("Subscribed");
        } catch (MqttException e) {
            e.printStackTrace();

        }

    }
    public void unsubscribe(){

        try{
            client.unsubscribe("lightcontrol/home/"+ homeID +"/light/+/info");
        } catch (MqttException e){
            e.printStackTrace();
        }
    }


    @Override
    // the following method to be invoked when the message arrived from broker for a topic subscribed to
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        System.out.println(message); // print out message revert back to client
        json = new JSONObject(message.toString()).getJSONObject("lightInfo");
     // declare a new JSON object and add the light info (fields) according to RFC17.
        // to instantiation and initialise the object
        LightObject light = new LightObject(json.getString("id"), json.getString("state")
                , json.getString("color"), json.getString("room"), json.getString("name"));
        LightObject roomLight = new LightObject(json.getString("id"), json.getString("state")
                , json.getString("color"), json.getString("room"), "undefined");

        setLightArray(light);  // initialise the array
        setRoomArray(roomLight);
        pingFragment();// validate connection btw client and broker.
    }

    // Message to change state of a light
    public void publish(LightObject light) {
        MessageHandler messageHandler = new MessageHandler();
        //message handler to handle the message logic, what to subscribe and what to publish
        try {
            String message = messageHandler.changeState(light).toString();
            client.publish("lightcontrol/home/"+ homeID +"/light/"+light.getId()+"/commands"
                    , message.getBytes(), 1, false);

        } catch (MqttException e) {
            e.printStackTrace();

        }
    }


    // Message to blink light by Li wei
    // whenever you trigger onclick events, the following method will be invoked
    public void publishBlink (LightObject light) {
        MessageHandler messageHandler = new MessageHandler();
        //To declared messagehandler object
        try {
            String message = messageHandler.changeState1(light).toString(); // declare the message type.
            client.publish("lightcontrol/home/"+ homeID +"/light/"+light.getId()+"/commands"
                    , message.getBytes(), 1, false);
        // publish the topic + message. (Key, value) pair
            BackGroundTask b1 = new BackGroundTask();
            b1.execute(message);

        } catch (MqttException e) {
            e.printStackTrace();

        }
    }

    class BackGroundTask extends AsyncTask<String, Void, Void>
    {
         Socket s;
         PrintStream writer;

        @Override
        protected Void doInBackground(String... voids) {

            try
            {
                 String message =voids[0];
                 s = new Socket("tcp://192.168.0.107", 1883);
             //   s = new Socket("prata.technocreatives.com", 1883);
                 writer = new PrintStream(s.getOutputStream());
                 writer.write(Integer.parseInt(message));
                 writer.flush();
                 writer.close();


            }catch (IOException changestate1)
            {
                changestate1.printStackTrace();
            }
            return null;
        }
    }


    //Message to change Light Color
    public void publishColor(LightObject light) {
        MessageHandler messageHandler = new MessageHandler();


        try {
            String message = messageHandler.changeColor(light).toString();
            client.publish("lightcontrol/home/"+ homeID +"/light/" + light.getId() + "/commands"
                    , message.getBytes(), 1, false);

            } catch (MqttException e) {
            e.printStackTrace();

        }
    }



    //Message to Change state of a Room
    public void publishRoom(LightObject room) {
        MessageHandler messageHandler = new MessageHandler();

        try {
            String message = messageHandler.changeState(room).toString();
            client.publish("lightcontrol/home/"+ homeID +"/room/" + room.getRoom() + "/commands"
                    , message.getBytes(), 1, false);

            } catch (MqttException e) {
            e.printStackTrace();

        }
    }

    //Message to change Room Color
    public void publishColorRoom(LightObject light) {
        MessageHandler messageHandler = new MessageHandler();

        try {
            String message = messageHandler.changeColor(light).toString();
            client.publish("lightcontrol/home/"+ homeID +"/room/" + light.getRoom() + "/commands"
                    , message.getBytes(), 1, false);

            } catch (MqttException e) {
            e.printStackTrace();

        }
    }

    //Message to change a lights name
    public void publishNameChange(LightObject light){
        MessageHandler messageHandler = new MessageHandler();

        try{
            String message = messageHandler.changeName(light).toString();
            client.publish("lightcontrol/home/"+ homeID +"/light/" + light.getId() + "/commands"
                    , message.getBytes(), 1, false);
            } catch (MqttException e){
            e.printStackTrace();
        }
    }


    //Move light to another room
    public void publishLightChangeRoom(LightObject light){
        MessageHandler messageHandler = new MessageHandler();

        try{
            String message = messageHandler.changeRoom(light).toString();
            client.publish("lightcontrol/home/"+ homeID +"/light/" + light.getId() + "/commands"
                    , message.getBytes(), 1, false);
        } catch (MqttException e){
            e.printStackTrace();
        }
    }

    //Change name of a room
    public void publishRoomChangeRoom(LightObject light, String oldRoom){
        MessageHandler messageHandler = new MessageHandler();

        try{
            String message = messageHandler.changeRoom(light).toString();
            client.publish("lightcontrol/home/"+ homeID +"/room/" + oldRoom + "/commands"
                    , message.getBytes(), 1, false);
        } catch (MqttException e){
            e.printStackTrace();
        }
    }

    //Publish JSON that's defined in other classes. Used for moods.
    public void publishJSON (String topic, JSONObject json){

        try{
            String message = json.toString();
            client.publish(topic,message.getBytes(),1,false);
            } catch (MqttException e){
            e.printStackTrace();
        }
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
    // Imqtttoken prvides a mechanism for tracking completion of asychronous tasks
    }

    @Override
    public void connectionLost(Throwable cause) {

    }

    static int rCounter = 0;

    // Array of Rooms
    private void setRoomArray(LightObject light) throws IOException {


        LightObject[] temp; // to declare array with type of LightObject
        boolean check = true;

        if (roomArray.length == 0) { // if array is empty
            roomArray = new LightObject[1]; // instantiation the array
            roomArray[0] = light; // to initialization an array

        }
        else{
            for(int i = 0; i < roomArray.length; i++){
                if(roomArray[i].getRoom().equals(light.getRoom())){
                    // use "getRoom" method to access array then to check matched resource from
                    // light object.
                    // (appearing in same fragment section of UI)
                    if(light.getState().equals("off")){ // to check  the initial state of
                        // selected light
                        roomArray[i].setState("off");
                    }else{
                        roomArray[i].setState("on");
                    }
                    check = false;
                }
            }
            if(check){ // if the item's position in roomArray has been checked
                temp = roomArray;
                roomArray = new LightObject[roomArray.length + 1];// instantiation the array
                for (int i = 0; i < temp.length; i++) {
                    roomArray[i] = temp[i]; // to initialization array with temp elements
                }
                roomArray[roomArray.length-1] = light;


            }
        }



    }

    // Set Array of lights
    private void setLightArray(LightObject light)
    {
      //  mainList = (ListView) findViewById(R.id.lightList); // instanilise the arraylist
      //  mainList.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>()));
     //   requestWindowFeature(Window.FEATURE_PROGRESS);

        LightObject[] temp;  // to declare temp array
        boolean check = false;

        int pos = 0;  // initial array index

        if (lightArray.length == 0)
        {    // if the array is empty
            lightArray = new LightObject[1]; // instantiation the array
            lightArray[0] = light; // initialization array
        }
        else
        {  // if the array is not empty
            for (int i = 0; i < lightArray.length; i++)
            {
                if (lightArray[i].getId().equals(light.getId()))
                { //  using "getID()
                    /*  to find matched resource from light object   */
                    pos = i;
                    check = true;
                    break;
                }
            }
            if (check)
            { // if the position in array has  not been checked
                lightArray[pos] = light;
            }
            else
            { // if the position in Lightarray has been  checked already
                temp = lightArray;
                lightArray = new LightObject[lightArray.length + 1];
                for (int i = 0; i < temp.length; i++)
                {
                    lightArray[i] = temp[i];  // initialisation of array with temp element
                }
                lightArray[lightArray.length - 1] = light;
            }
        }
       //    new MyTask().execute();

    }

 //   class MyTask extends AsyncTask<Void, LightObject, Void>
  //  {
 //     private ArrayAdapter<LightObject> adapter;




  //      @Override


  //      protected void onPreExecute() {
  //          adapter = (ArrayAdapter<LightObject>) mainList.getAdapter();
  //          setProgressBarIndeterminate(false);
  //      }

 //       protected Void doInBackground(Void... voids) {
 //           for (LightObject light : lightArray){
 //               publish(light);
  //          }

 //           return null;
  //      }
//
 //       protected void onProgressUpdate(LightObject... values){
  //          adapter.add(values[0]);
          //  count++;
 //       }

  //      protected  void onPostExecute(Void result){
//            super.onPostExecute(result);
 //       }
 //   }



    // Get array of Rooms
    public LightObject[] getRoomArray() {

        return roomArray;
    }


    // Get array of Lights
    public LightObject[] getLightArray() {

        return lightArray;
    }

    //When homeId is changed, we empty room and light arrays to make space for the ones in the new home.
    public void resetData(){
        lightArray = new LightObject[0];
        roomArray = new LightObject[0];
    }


    //Uses the callback function from interface to inform MainActivity that new data is ready to use.
    private void pingFragment(){
        cl.callback("success");
    }

    @Override
    public void run() {

    }
}