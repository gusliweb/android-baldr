package com.gu.example.axel.baldr;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.IdRes;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.roughike.bottombar.BottomBar;
import com.roughike.bottombar.OnTabSelectListener;

//Roughike BottomBar: https://github.com/roughike/BottomBar

/**
 * Created by Axel on 02-Oct-16.
 */
public class MainActivity extends AppCompatActivity implements CustomListener{

    private int fabState = 1;
    BottomBar bottomBar;
    private Toolbar toolbar;
    FloatingActionButton fab;
    SharedPreferences preferences;
    MqttConnection connection;

    public String homeID;

    LightFragment lightFragment;
    RoomFragment roomFragment;
    MoodFragment moodFragment;




    @Override
    // the following method is use to load layout for new  activity
    protected void onCreate(Bundle savedInstanceState) {
        // bundle is hash map object to store the data
        //onCreate: responsible for create new activity
        //savedInstanceState is reference to bundle which to store and retrieve the state of activity

        super.onCreate(savedInstanceState); // place all state related data on this parameter.
        // call super class constructor to create view hierarchy
        lightFragment = new LightFragment();
        roomFragment = new RoomFragment();
        moodFragment = new MoodFragment();


        setContentView(R.layout.activity_main);
    //    LooperThread thread = new LooperThread();
     //   thread.
        // SetContentView is used to fill the window with the UI provided from layout file
        // in case of setContentView(R.layout.somae_file).
        // once your layout created in XML file, you can load your layout resource into your codes
        Context context = getApplicationContext();
         // return context of entire application
         // if you need a context tied to life cycle of entire application not just current activity

        // preference class represent a basic UI building block displayed by preferenceActivity in
        // the form of listView
        // preferencemanager is to help load preference from xml file in your app with default value and hold it's
        //reference to " SharedPreference"
        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        //Used to help create Preference hierarchies from activities or XML.
        //sharedpreference allow to saved and retrieve data in a  (Key, Value) pair.
        homeID = preferences.getString("homeID", "");

        if(homeID.equals("")){
            homeID = "asdf";
            SharedPreferences.Editor editor = preferences.edit();// using editor to write in the preference.
            editor.putString("homeID", homeID);
            editor.commit();
        }

        // the program block above represent set and read the preference setting then commit changes


        // following directory in resource folder to find the resource file(XML) according to resource ID of view
        // instantialize app bar by following method .

        //initialize member Toolbar so we can manipulate it later
        toolbar = (Toolbar) findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);
       // create a new fragment called fab
        fab = (FloatingActionButton)findViewById(R.id.fab);
        fab.bringToFront();
         // using fragmentmanager to manage interaction btw activity and fragment inside it.
        // or using fragmentSupportManager to handle trasaction among fragments.

        getSupportFragmentManager()
                .beginTransaction()
                // replace whatever is in fragment_container view with  lightFragment
                .replace(R.id.frame,lightFragment)
                .commit();


        connection = new MqttConnection(this, this);
        connection.connect();


        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // to register a callback onClick listener  to be invoked if the view is clicked in order to open new
                //fragment
                if (fabState == 1) {
                    //Add light
                    AddLightFragment f = new AddLightFragment();
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.frame,f)
                            .addToBackStack(null) // add transaction to backstack
                            .commit();
                    fab.hide();
                    setTitle("Add Light");
                }
                else if (fabState == 3){
                    //Add mood
                    AddMoodFragment f = new AddMoodFragment();
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.frame,f)
                            .addToBackStack(null)
                            .commit();
                    fab.hide();
                    setTitle("Add Mood");
                }
            }
        });

        //Setting listener for the bottombar, switching fragments and altering the FAB.
        bottomBar = (BottomBar) findViewById(R.id.bottomBar);
        bottomBar.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelected(@IdRes int tabId) {
                if (tabId == R.id.lightTab){
                    fabState = 1;
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.frame,lightFragment)
                            .commit();
                    fab.show();
                    setTitle("Lights");

                }
                else if (tabId == R.id.roomTab){
                    fabState = 2;
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.frame,roomFragment)
                            .commit();
                    fab.hide();
                    setTitle("Rooms");
                }
                else if (tabId == R.id.moodTab){
                    fabState = 3;
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.frame, moodFragment)
                            .commit();
                    fab.show();
                    setTitle("Moods");
                }
            }

        });
    }

    public void editLight(LightObject data){
            LightObject light = data;
            String color = light.getColor();
            EditLight f = new EditLight(color, light);
            this.getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.frame, f)
                    .addToBackStack(null)
                    .commit();
            fab.hide();
            setTitle("Edit " + light.getName());
    }



    public void editRoom(LightObject data){
        LightObject light = data;
        String color = light.getColor();
        EditRoom f = new EditRoom(color, light);
        this.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.frame, f)
                .addToBackStack(null)
                .commit();
        fab.hide();
        setTitle("Edit " + light.getRoom());
    }
    public void settings(){
        SettingsFragment f = new SettingsFragment();
        this.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.frame, f)
                .addToBackStack(null)
                .commit();
        fab.hide();
        setTitle("Settings");
    }

    public void updateHomeId(String input){
        homeID = input;
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("homeID", homeID);
        editor.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        settings();
        return true;
    }


    @Override
    public void onBackPressed() {
        if(getSupportFragmentManager().getBackStackEntryCount() == 0) {
            super.onBackPressed(); // Return the number of entries currently in the back stack.
        }
        else {
            getSupportFragmentManager().popBackStack(); // if you want to go back to previous fragment
            // from backstack, just call popBackStack() method.
            fab.show();
        }
    }

    @Override
    public void callback(String result) {
        if(fabState == 1){
            lightFragment.setLights(connection.getLightArray());
        }
        else if(fabState == 2) {
            roomFragment.setRooms(connection.getRoomArray());
        }
    }
}
