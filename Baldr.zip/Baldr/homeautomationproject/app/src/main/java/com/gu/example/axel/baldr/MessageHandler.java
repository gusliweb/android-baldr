package com.gu.example.axel.baldr;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;
//import android.os.Handler;
/**
 * Created by Axel on 01-Dec-16.
 */

public class MessageHandler {

    public MessageHandler(){

    }

    // Json message to change state of Light or Room
    public JSONObject changeState(LightObject light){
        String state = light.getState();

        if(state.equals("on"))
            state = "off";
        else
            state = "on";

        JSONObject jsonOuter = new JSONObject();
        JSONObject json = new JSONObject();

        try {
            jsonOuter.put("version", 1);
            jsonOuter.put("protocolName", "baldr");
            jsonOuter.put("lightCommand", json.put("state", state));
            // as Json object was written in format (Key, Value) pair
            // we use nested object to enter the values into the Json objects.
            // the inner object statement itself can be treated as a value for outter object


        }catch(JSONException e){
            System.out.println(e);
        }

        light.setState(state);

        return jsonOuter; // because we eventually can only return one object
    }

// Json message to blink lamp created by Li wei
    public JSONObject changeState1(LightObject light) {

          String state = light.getState();
        // int stateCounter  = 0;
        // the for loop will make lamp to flickery 5 times before it switch off

        //  Timer timer = new Timer();
        //  timer.schedule( new TimerTask() {


        while (true) {               // " i" is stateCounter
            for (int i = 0; i < 5; i++) {
              //  final String state = " " + light.getState();
              //  Runnable x = new Runnable() {

              //      public void run() {
                        //  String  state= light.getState();
                        if (state.equals("on") && i % 2 == 1)

                        { // if the stateCounter % 2 == 1 then the state will be "on"
                            state = "off ";  // the state will switch to "off"
                            //  System.out.println("  " + state);
                        } else if (state.equals("on") && i % 2 == 0)

                        {
                            state = "off";  // the state will switch to "off"
                            // System.out.println("  " + state);
                        } else if (state.equals("off") && i % 2 == 1)

                        {
                            state = "on";  // the state will switch to "off"
                            //  System.out.println("  " + state);
                        } else

                        {
                            state = "on ";  // vice verse also hold
                            //  System.out.println("  " + state);
                        }

                        try {
                            // System.out.println("  " + state);
                            Log.i(" ", state);
                            Thread.sleep(2000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                    }




                JSONObject jsonOuter;
                jsonOuter = new JSONObject();
                JSONObject json = new JSONObject();
                // when put errors message or value into Json object  then throw out Exception
                try {
                    jsonOuter.put("version", 1);
                    jsonOuter.put("protocolName", "baldr");
                    jsonOuter.put("lightCommand", json.put("state1", state));

                } catch (JSONException e) {
                    System.out.println(e); // print out exception
                }

                light.setState(state);

                return jsonOuter;
            }

        }




    // Json message to change color of Light or Room
    public JSONObject changeColor(LightObject light){
         String color = light.getColor();

        JSONObject jsonOuter = new JSONObject();
        JSONObject json = new JSONObject();

        try {
            jsonOuter.put("version", 1);
            jsonOuter.put("protocolName", "baldr");
            jsonOuter.put("lightCommand", json.put("color", color));
        }catch(JSONException e){
            System.out.println(e);
        }

        light.setColor(color);

        return jsonOuter;
    }

    public JSONObject changeName(LightObject light){
        String name = light.getName();

        JSONObject jsonOuter = new JSONObject();
        JSONObject json = new JSONObject();

        try {
            jsonOuter.put("version", 1);
            jsonOuter.put("protocolName", "baldr");
            jsonOuter.put("lightCommand", json.put("name", name));
        }catch(JSONException e){
            System.out.println(e);
        }

        light.setName(name);

        return jsonOuter;
    }

    public JSONObject changeRoom(LightObject light){
        String room = light.getRoom();

        JSONObject jsonOuter = new JSONObject();
        JSONObject json = new JSONObject();

        try {
            jsonOuter.put("version", 1);
            jsonOuter.put("protocolName", "baldr");
            jsonOuter.put("lightCommand", json.put("room", room));
        }catch(JSONException e){
            System.out.println(e);
        }

        light.setRoom(room);

        return jsonOuter;
    }

}
