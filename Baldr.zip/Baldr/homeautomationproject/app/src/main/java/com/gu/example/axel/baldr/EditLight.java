package com.gu.example.axel.baldr;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup; // viewGroup is special kind of view including other view(child view)
import android.support.v4.app.Fragment;
import android.widget.Button;
import android.widget.EditText;
import yuku.ambilwarna.AmbilWarnaDialog;


/**
 * Created by Axel on 06-Oct-16.
 */

public class EditLight extends Fragment {


    private String colorStr;

    private String lName;
    private String rName;

    public AmbilWarnaDialog dialog;
    Button colorBtn;
    Button blinkBtn;
    Button saveAll;

    MainActivity ma;

    EditText editLname;
    EditText editRname;


    LightObject light;
   //Default constructor provides the default values to the object like 0, null etc
    public EditLight (){

    }


    /**
     * @param colorStr
     * @param light
     */
    // constructor to initialize the field of object
    public EditLight(String colorStr, LightObject light){
        //Parameterized constructor is used to provide different values to the distinct objects
        this.colorStr = colorStr;  // "this" is reference to object itself
        this.light = light; // using "this" keyword to signals to compiler that the field of object
        // that is being refer to
        lName = this.light.getName();
    }


   // creates and returns the view hierarchy associated with the fragment.
    // layoutinflater: is used to get the view object which defined in a layout xml.
    //  ViewGroup: If non-null, this is the parent view that the activity's UI should be attached to.
   // The activity should not add the view itself but this can be used to generate the LayoutParams of the view.
    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.edit_light, container, false);
        //onCreateView is called to inflate the layout of the activity i.e graphical initialization usually takes place here.
        // It is always called sometimes after the onCreate method.
        //inflater.inflate is to add view to edit_light layout (runtime activity)
        ma = (MainActivity) container.getContext();
          // return context  of current running activity
          //   why use."context"
        // 1.loading common resources
        //   2.creating dynamic view
        //3. launching activities

        // show a color picker dialog box
        dialog = new AmbilWarnaDialog(getContext(), 000000, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            // You cannot call a constructor directly, to instantiate a class use the new keyword
            @Override
            public void onCancel(AmbilWarnaDialog dialog) {

            }

            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {
                // constructor return colour picker
                // Get Hex color code and convert integer to hex string
                // substring method to remove alphabet part
                 colorStr = "#" +Integer.toHexString(color).substring(2).toUpperCase();

                System.out.println("Before set color: " + light.getId() + " had " + light.getColor());
               light.setColor(colorStr);
                System.out.println("After set color: " + light.getId() + " has " + light.getColor());
                ma.connection.publishColor(light);

                dialog.show(); // show color picker dialog box

            }
        });


       // initialize member editLname so we can manipulate it later
        editLname = (EditText) view.findViewById(R.id.editLname);
        editLname.setText(light.getName());
        // set the text for editName variable
        editRname = (EditText) view.findViewById(R.id.editRname);
        editRname.setText(light.getRoom());


        // to invoking button ID from XML file
        //initialize member savaAll so we can manipulate it later
        saveAll = (Button) view.findViewById(R.id.saveAll);
        saveAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // if both inputs for light's and room's name don't match the current content from
                // text field
                if(!editLname.getText().toString().equals(light.getName()) &&
                        !editRname.getText().toString().equals(light.getRoom())){
                    // set the text for both variables
                    light.setName(editLname.getText().toString());
                    light.setRoom(editRname.getText().toString());

                    ma.connection.publishNameChange(light);
                    ma.connection.publishLightChangeRoom(light);
                }
               // check does  the input Lname match with current name
                else if(!editLname.getText().toString().equals(light.getName())){
                    light.setName(editLname.getText().toString());

                    ma.connection.publishNameChange(light);
                }
                // check whether or not input Rmane match with current content
                else if(!editRname.getText().toString().equals(light.getRoom())){
                    light.setRoom(editRname.getText().toString());
                    ma.connection.publishLightChangeRoom(light);
                }
                else{
                    System.out.println("Nothing changed");
                }
            }
        });
        // initialize member colorbtn so we can manipulate it later
        colorBtn = (Button) view.findViewById(R.id.colorBtn);

        colorBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dialog.show();
            }
        });
        // to register a callback listener to listen onClick events.

        // correspondent to "blink" button click created by Li wei
        // initialize member blinkBtn so we can manipulate it later
        blinkBtn = (Button) view.findViewById(R.id.blinkBtn);
        // to invoking button ID from XML file
        blinkBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //OnClickListener is an interface defined into the View class
               // notify();
                ma.connection.publishBlink(light);
                // calling the method in MQTTconnection class via mainActivity
            }
        });



        return view;
    }


}